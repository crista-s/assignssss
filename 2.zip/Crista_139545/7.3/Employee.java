
public class Employee implements Comparable<Employee>{
	private int id;
	private String name;
	private long salary;
	private Designation designation;
	private InsuranceScheme insuranceScheme;
	
	public Employee() {
	}

	public Employee(int id, String name, long salary, Designation designation,
			InsuranceScheme insuranceScheme) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public Designation getDesignation() {
		return designation;
	}

	public void setDesignation(Designation designation) {
		this.designation = designation;
	}

	public InsuranceScheme getInsuranceScheme() {
		return insuranceScheme;
	}

	public void setInsuranceScheme(InsuranceScheme insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	
	@Override
	public int hashCode() {
		return id;
	}
	
	
	@Override
	public String toString() {
		return "Employee [empid=" + id + "\n name=" + name + "\n salary=" + salary + "\n Designation="+designation+"\n Insurance Scheme="+insuranceScheme+"]";
	}
	@Override
	public int compareTo(Employee o) {
		return (int)o.salary-(int)this.salary;
	
	}
}
