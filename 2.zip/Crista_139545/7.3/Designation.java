
public enum Designation {
	System_Associate,Programmer,Manager,Clerk
}
