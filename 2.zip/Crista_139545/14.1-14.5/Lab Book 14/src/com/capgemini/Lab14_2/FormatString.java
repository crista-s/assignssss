package com.capgemini.Lab14_2;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class FormatString {

	public static void main(String[] args) {
		Consumer<String> consumer = (str) -> System.out.println(str.replace("", " ").trim());
		Supplier<String> supplier =()->"CapGemini";
		
		consumer.accept(supplier.get());

	}

}
