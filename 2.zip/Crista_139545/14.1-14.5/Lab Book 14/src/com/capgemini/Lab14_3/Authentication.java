package com.capgemini.Lab14_3;

import java.util.Scanner;
import java.util.function.BiFunction;

public class Authentication {

	public static void main(String[] args) {
		String username="admin";
		String password="123";
		System.out.println("Enter username and password");
		Scanner sc=new Scanner(System.in);
		String user=sc.next();
		String pass=sc.next();
		BiFunction<String, String, Boolean> authenticate=(user1, pass1)-> (user1.equals(username)&&pass1.equals(password));
		System.out.println("Result is:" + authenticate.apply(user, pass));
	}

}
