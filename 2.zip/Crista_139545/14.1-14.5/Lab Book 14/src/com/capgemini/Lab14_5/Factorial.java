/**
 * 
 */
package com.capgemini.Lab14_5;

/**
 * @author
 *
 */
public class Factorial {

	public static int fact(int num)
	{
		int fact=1;  
		for(int i=1;i<=num;i++)
			fact=fact*i;    
		return fact;	
	}

}
