import java.util.Arrays;


public class StringSort {

	public static void main(String[] args) {

		String products[]={"Paper","Pen","Notepad","stapler","Gemclips"};
		Arrays.sort(products);
		for (int i = 0; i < products.length; i++) {
			System.out.println(products[i]);
		}
		
	}

}
