
public class AccountHolder {

	public static void main(String[] args) {
		
		Person person1 = new Person("Smith",".",Gender.M);
		Person person2 = new Person("kathy",".",Gender.F);
		
		Account accountPerson1 = new Account(2000,person1);
		Account accountPerson2 = new Account(3000,person2);
		
		//Before update
		System.out.println("------------ Before Update ------------------");
		System.out.println(accountPerson1);
		System.out.println(accountPerson2);
		
		accountPerson1.deposit(2000);		
		accountPerson2.withdraw(2000);
		
		
		//After Update
		System.out.println("------------- After Update -------------------");
		System.out.println(accountPerson1);
		System.out.println(accountPerson2);		
	}

}
