package Practicalfour;

public abstract class AbstractAcc {

	public abstract boolean withdraw(double wid);
}
