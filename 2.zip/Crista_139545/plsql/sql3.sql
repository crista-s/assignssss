CREATE TABLE Staff_Master_Back(
	old_salary NUMBER(10),
	new_salary NUMBER(10)
);