CREATE OR REPLACE FUNCTION age(dob DATE)

RETURN NUMBER
IS
	cal_age NUMBER;
	
BEGIN
	
	cal_age := TO_CHAR(sysdate,'YYYY') - TO_CHAR(dob,'YYYY');
	
	DBMS_OUTPUT.PUT_LINE(cal_age);
	RETURN cal_age;

END;
/