DECLARE
	v_employee Employee%ROWTYPE;
	v_salary Employee.Salary%TYPE;
	v_sal_cal NUMBER;
	v_sal_cal2 NUMBER;
	v_department_no NUMBER;
	
BEGIN
	
	v_department_no := &deptno;
	
	SELECT *
	INTO v_employee
	FROM Employee
	WHERE Department_no = v_department_no;
	
	v_salary := v_employee.Salary;
	v_sal_cal := v_employee.Salary + (v_employee.Salary * .3);
	v_sal_cal2 := v_employee.Salary + 5000;
	
	IF(v_sal_cal < v_sal_cal2) THEN
		UPDATE Employee
		SET Salary = Salary + (Salary * .3)
		WHERE Department_no = v_department_no;
	
	ELSE
		UPDATE Employee
		SET Salary = Salary + 5000
		WHERE Department_no = v_department_no;
	
	END IF;
	
	
	DBMS_OUTPUT.PUT_LINE('salary updated with department no-' || v_department_no);
	DBMS_OUTPUT.PUT_LINE('updated salary-' || v_employee.Salary);

END;
/