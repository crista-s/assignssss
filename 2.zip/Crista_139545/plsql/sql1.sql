
CREATE TABLE Department(
  Department_no    NUMBER(4,0) PRIMARY KEY,
  Department_Name  VARCHAR2(16),
  Location         VARCHAR2(15)
);
 
 CREATE TABLE Employee(
  Employee_no    NUMBER(5,0) PRIMARY KEY,
  Employee_Name  VARCHAR2(20),
  Job            VARCHAR2(8),
  Hire_Date      DATE,
  Salary         NUMBER(6,2),
  Commission     CHAR(5),
  Department_no  NUMBER(3,0) REFERENCES Department(Department_no),
  CHECK(Commission IN('yes','no'))
);


INSERT INTO Department
VALUES(1, 'HR', 'KOLKATA');
INSERT INTO Department
VALUES(2, 'RESEARCH', 'MUMBAI');
INSERT INTO Department
VALUES(3, 'SERVICE', 'HYDRABAFD');
INSERT INTO Department
VALUES(4, 'CODING', 'MUMBAI');
INSERT INTO Department
VALUES(5, 'CODIING', 'BANGALORE');




INSERT INTO Employee
VALUES(7859, 'prolay', 'CODER',
 to_date('12-11-2007','dd-mm-yyyy'),
 5000, 'yes', 5);
INSERT INTO Employee
VALUES(6541, 'abhik', 'MANAGER', 
 to_date('11-5-2009','dd-mm-yyyy'),
 2850, 'no', 2);
INSERT INTO Employee
VALUES(7369, 'sahir', 'HR', 
 to_date('17-12-2011','dd-mm-yyyy'),
 800, 'no', 1);
INSERT INTO Employee
VALUES( 9514, 'dibendu', 'SALESMAN',
 to_date('2-2-2008','dd-mm-yyyy'),
 1600, 'yes', 3);
INSERT INTO Employee
VALUES( 7689, 'suresh', 'SALSMAN', 
 to_date('2-9-2009','dd-mm-yyyy'),
 1250, 'yes', 4);

