package Caller;

public class acceptNumber {

	public static void main(String[] args) {
		
		if (args.length == 1) {
			double num=Double.parseDouble(args[0]);
            if(num>=0)
            	System.out.println("Positive Number");
            else
            	System.out.println("Negative Number");
        }

	}
}