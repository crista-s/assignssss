package Practicaltwo;

import java.util.Scanner;


public class Person2 {

	public static void main(String[] args) {
		
		Gender gen;
		Scanner scinput = new Scanner(System.in);
		PersonEntity2 ob = new PersonEntity2();
		
		System.out.println("Enter the First Name: ");
		String firstname= scinput.nextLine();
		
		System.out.println("Enter the Second Name: ");
		String lastname= scinput.nextLine();
		
		System.out.println("Enter the Gender: 0 for Male or 1 for female");
		int gender= scinput.nextInt();
					scinput.nextLine();
		
		switch(gender)
		{
		case 0:
			gen = Gender.M;
			break;
		case 1:
			gen = Gender.F;
			break;
		
		default:
			System.out.println("Invalid Gender");
			break;
		}
		
		
		System.out.println("Enter the phone number: ");
		String phone= scinput.nextLine();
		
		ob = new PersonEntity2(firstname,lastname,Gender.M,phone);
		
		ob.display();
	}

}
