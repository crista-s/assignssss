package Caller;

import java.util.Scanner;

import Caller.EnumDemo.Gender;

public class PersonClassMain {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		try{
			
			System.out.println("Enter Person Details: ");
			System.out.println("First Name: ");
			String s1=sc.nextLine();
			
			System.out.println("Last Name: ");
			String s2=sc.nextLine();
			
			System.out.println("Gender: ");
			String ch=sc.nextLine();
			
			System.out.println("Phone No: ");
			String phn=sc.nextLine();
			
			PersonClass p1=new PersonClass(s1,s2,Gender.valueOf(ch),phn);
			
			System.out.println("Person Details: ");
			System.out.println("_____________________________________");
			System.out.println("First Name: "+p1.getFirstName());
			System.out.println("Last Name: "+p1.getLastName());
			System.out.println("Gender: "+p1.getGender());
			System.out.println("Phone No: "+p1.getPhoneNo());
		}
		catch(myException m)
		{
			System.out.println("Exception occured: "+m);
		} 
	}

}
