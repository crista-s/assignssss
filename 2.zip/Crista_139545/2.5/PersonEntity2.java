package Practicaltwo;

public class PersonEntity2 {
	
	public String firstName;
	public String lastName;
	public String phone;
	public Gender gender;
	
	public PersonEntity2()
	{
		
	}
	
	
	
	public PersonEntity2(String firstName, String lastName, Gender gender, String phone) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phone = phone;
	}



	public void display()
	{
		System.out.println("Person Details: ");
		System.out.println("_________________");
		System.out.println("First Name: "+ firstName);
		System.out.println("Last Name: "+ lastName);
		System.out.println("Gender: "+gender);
		System.out.println("Phone Number: "+phone);
	}

}
