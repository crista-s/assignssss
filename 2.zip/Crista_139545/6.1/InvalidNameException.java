
class InvalidNameException extends Exception {
	
	public InvalidNameException(String s){
        // Call constructor of parent Exception
        super(s);
    }
}
