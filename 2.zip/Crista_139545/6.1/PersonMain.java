import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		
		String fname;
		String lname;
		Gender gender = Gender.F;
		int gen=0;
		long phoneNumber;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.println("Enter your First Name: ");
		fname=scInput.nextLine();
		
		System.out.println("Enter your Last Name: ");
		lname=scInput.nextLine();
		
		System.out.println("Enter your mobile number");
		phoneNumber=scInput.nextLong();
					scInput.nextLine();
					
		System.out.println("Enter your Gender(1:Male 2:Female)");
		gen=scInput.nextInt();
			scInput.nextLine();
		
		System.out.println("Enter your birth date in dd/MM/yyyy format:");
		String input  = scInput.nextLine();
		LocalDate birthDate = LocalDate.parse(input,formatter);
		
		switch(gen){
		case 1:
			gender=Gender.M;
			break;
		case 2:
			gender=gender.F;
			break;
		default:
			System.out.println("Invalid Gender");
			break;
		}
		
		Person person = new Person(fname,lname,gender);
		person.setPhoneNumber(phoneNumber);
		person.calculateAge(birthDate);
		try{
			person.setFullName(fname,lname);
			person.display();
		}catch (InvalidNameException ex)
        {
            System.out.println(ex.getMessage());
        }
		
		
		scInput.close();
	}

}
