package com.cg.eis.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.cg.eis.bean.Designation;
import com.cg.eis.bean.Employee;
import com.cg.eis.bean.InsuranceScheme;
import com.cg.eis.exception.EmployeeException;

public class Service extends Employee implements IEmployeeService {
	
	public void getEmployeeDetails(Employee employee) throws EmployeeException{
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Employee Id: ");
		employee.setId(sc.nextInt());
		sc.nextLine();
		
		System.out.println("Enter Employee Name: ");
		employee.setName(sc.nextLine());
		
		System.out.println("Enter the salary of the Employee: ");
		double salary = sc.nextDouble();
		if(salary<3000){
			throw new EmployeeException("Salary must be greater than 3000");
		}
		employee.setSalary(salary);
		salary = employee.getSalary();
		if(salary>5000 && salary<20000){
			employee.setDesignation(Designation.System_Associate);
		}else if(salary>=20000 && salary<=40000){
			employee.setDesignation(Designation.Programmer);
		}else if(salary>=40000){
			employee.setDesignation(Designation.Manager);
		}else{
			employee.setDesignation(Designation.Clerk);
		}
		
		sc.close();
	}
	
	public void setInsuranceScheme(Employee employee){
		
		double salary = employee.getSalary();
		Designation designation = employee.getDesignation();
		
		if(salary>5000 && salary<20000 && designation==Designation.System_Associate){
			employee.setInsuranceScheme(InsuranceScheme.SchemeC);;
		}else if(salary>=20000 && salary<=40000 && designation==Designation.Programmer){
			employee.setInsuranceScheme(InsuranceScheme.SchemeB);;
		}else if(salary>=40000 && designation==Designation.Manager){
			employee.setInsuranceScheme(InsuranceScheme.SchemeA);;
		}else{
			employee.setInsuranceScheme(InsuranceScheme.NoScheme);;
		}
		
		try {
			FileOutputStream f = new FileOutputStream(new File("myObjects.txt"));
			ObjectOutputStream o = new ObjectOutputStream(f);

			// Write objects to file
			o.writeObject(employee);

			o.close();
			f.close();
		}catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			System.out.println("Error initializing stream");
		} 
	}
	
	public void showEmployeeDetails(Employee employee){
		
		System.out.println("Employee Details");
		System.out.println("--------------------------");
		System.out.println("Employee ID: " +employee.getId());
		System.out.println("Employee Name: " +employee.getName());
		System.out.println("Salary: " +employee.getSalary());
		System.out.println("Designation: " +employee.getDesignation());
		System.out.println("Insurance Scheme: " +employee.getInsuranceScheme());
	}
	
	
}
