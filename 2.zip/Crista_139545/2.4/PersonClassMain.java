package Caller;

import java.util.Scanner;

import Caller.EnumDemo.Gender;

public class PersonClassMain {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Person Details: ");
		System.out.println("First Name: ");
		String fname=sc.nextLine();
			
		System.out.println("Last Name: ");
		String lname=sc.nextLine();
			
		System.out.println("Gender: ");
		String gender=sc.nextLine();
			
		System.out.println("Phone No: ");
		String phn=sc.nextLine();
			
		PersonClass p1=new PersonClass(fname,lname,gender,phn);
			
		System.out.println("Person Details: ");
		System.out.println("_____________________________________");
		System.out.println("First Name: "+p1.getFirstName());
		System.out.println("Last Name: "+p1.getLastName());
		System.out.println("Gender: "+p1.getGender());
		System.out.println("Phone No: "+p1.getPhoneNo());
		
	}

}
