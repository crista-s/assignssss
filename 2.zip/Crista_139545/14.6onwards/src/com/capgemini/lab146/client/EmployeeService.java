package com.capgemini.lab146.client;

import java.util.Scanner;

import com.capgemini.lab146.entity.EmployeeRepository;

public class EmployeeService {

	public static void main(String[] args) {
		EmployeeRepository emplRepo = new EmployeeRepository();
		
		Scanner sc=new Scanner(System.in);

		System.out.println("Select an operation to be performed: ");
		System.out.println("1. Sum salaries");
		System.out.println("2. List Employees with months & days");
		System.out.println("3. Employees without department");
		System.out.println("4. Only departments");
		System.out.println("5. Employees & day of week of hiring");

		int choice=sc.nextInt();

		switch(choice)
		{
		case 1:
			//1. Sum salaries
			System.out.println("Sum of all salaries: " + emplRepo.getAllSalarySum());
			break;
		
		case 2:		
			//2. List Employees with months & days
			emplRepo.listEmployeesMonthDays();
			break;
				
		case 3:
			//3. Employees without department
			emplRepo.employeesWithoutDepartment();
			break;
			
		case 4:	
			//4. Only departments
			emplRepo.onlyDepartments();
			break;
			
		case 5:	
			//5. Employees & day of week of hiring
			emplRepo.dayOfWeek();
			break;

		default:
			System.out.println("Invalid option. Please choose a valid option.");
			break;
			
		}
		
		sc.close();
	}

}