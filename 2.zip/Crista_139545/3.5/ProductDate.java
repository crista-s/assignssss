import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ProductDate {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		System.out.print("Enter Product Purchase date in dd/MM/yyyy format:");
		String input  = scanner.nextLine();
		LocalDate start = LocalDate.parse(input,formatter);
		
		System.out.println("Enter warrantee month period of the product: ");
		int month = scanner.nextInt();
		
		System.out.println("Enter warrantee year period of the product: ");
		int year = scanner.nextInt();
		
		LocalDate newDate = start.plusYears(year);
		LocalDate expDate = newDate.plusMonths(month);
		
		System.out.println("Expire Date of your product is: "+expDate.format(formatter));
		scanner.close();
	}

}
