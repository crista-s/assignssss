package com.cg.eis.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl {
	
	Employee employee = new Employee();
	HashMap<String ,Employee> list = new HashMap<String ,Employee>();
	
	//ADD_EMPLOYEE
	public void addEmployee(Employee emp){
		
		list.put(""+emp.getId(), emp);
	}
	
	
	//DELETE_EMPLOYEE
	public void deleteEmployee(int id){
		int flag = 0;
		for(Employee employee : list.values()){
			
			if(employee.getId()==id){
				list.remove(""+id);
				flag = 1;
				break;
			}
				
		}
		if(flag == 1)
		{
			//list.remove(""+id);
			System.out.println("\nSelected employee id's details have been deleted\n");
		}
		else{
			System.out.println("\nMentioned ID is not in record\n");
		}
			
	}
	
	//Insurance_Sceheme_based_EMPLOYEE_details
		public void ISEmployee(InsuranceScheme IS){

			for(Employee employee : list.values()){
				
				if(employee.getInsuranceScheme()==IS){
					System.out.println();
					System.out.println(employee);
					System.out.println();
				}
			}
				
		}
		// Sorting based on Salary
		public void salaryEmployee(){
			Set<String>empids = list.keySet();
			
			List<Employee>employees = new ArrayList<>();
			
			for(String empid : empids){
				employees.add(list.get(empid));
			}
			Collections.sort(employees);
			
			for(Employee employee : employees){
				System.out.println(employee);
			}
			

		}
		
}